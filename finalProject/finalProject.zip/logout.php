<?php 

	include("Controllers/logout_controller.php");

?>